-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1:3306
-- 生成日期： 2019-04-22 03:15:45
-- 服务器版本： 5.7.23
-- PHP 版本： 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `demo`
--

-- --------------------------------------------------------

--
-- 表的结构 `my_employee`
--

DROP TABLE IF EXISTS `my_employee`;
CREATE TABLE IF NOT EXISTS `my_employee` (
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `firstName` varchar(40) DEFAULT NULL,
  `lastName` varchar(40) DEFAULT NULL,
  `salary` int(11) DEFAULT NULL,
  `done` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `my_employee`
--

INSERT INTO `my_employee` (`username`, `password`, `firstName`, `lastName`, `salary`, `done`, `id`) VALUES
('e002', 'e002', 'e002', 'e002', 2000, NULL, 2),
('e001', 'e001', 'e001', 'e001', 1000, NULL, 1);

-- --------------------------------------------------------

--
-- 表的结构 `my_loss`
--

DROP TABLE IF EXISTS `my_loss`;
CREATE TABLE IF NOT EXISTS `my_loss` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` varchar(20) NOT NULL,
  `firstName` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `permanentAddress` varchar(40) NOT NULL,
  `temporaryAddress` varchar(40) NOT NULL,
  `airline` varchar(20) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `postCode` varchar(20) NOT NULL,
  `fNo` varchar(20) NOT NULL,
  `date` varchar(20) NOT NULL,
  `fromP` varchar(20) NOT NULL,
  `toP` varchar(20) NOT NULL,
  `typeColor` varchar(40) NOT NULL,
  `brandName` varchar(40) NOT NULL,
  `more` varchar(100) NOT NULL,
  `userId` int(11) NOT NULL,
  `pay` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `my_loss`
--

INSERT INTO `my_loss` (`id`, `pid`, `firstName`, `email`, `permanentAddress`, `temporaryAddress`, `airline`, `status`, `postCode`, `fNo`, `date`, `fromP`, `toP`, `typeColor`, `brandName`, `more`, `userId`, `pay`) VALUES
(1, 'aaaa', '', '', '', 'aaaa', 'aaa', 0, '0', '', '2019-04-30', '', '', '', '', '', 1, 0),
(2, 'bbbbbbb', 'bbbbbbbb', 'bbb@bb.bbbbb', 'bbbbbb', 'bbbbbbbbb', 'bbbbbbb', 0, 'bbbbbb', 'bbbbbbbbb', '2019-05-01', 'bbbbbbbb', 'bbbbbbb', 'bbbbbb', 'bbbbbbbbbb', 'bbbbbbbbbbbbbbbbbbbb', 1, 0),
(3, 'aaaa', 'aaaa', 'aaaa@aaaa.aaaa', 'aaaa', 'aaaa', 'aaaa', 0, 'aaaa', 'aaaa', '2019-04-07', 'aaaa', 'aaaa', 'aaaa', 'aaaa', 'aaaaa', 27, 0),
(4, 'cccc', 'cccc', 'cccc@cccc.cccc', 'cccc', 'cccc', 'cccc', 0, 'cccc', 'cccc', '2019-04-30', 'cccc', 'cccc', 'cccc', 'cccc', '', 29, NULL),
(5, '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', 29, NULL),
(6, 'eeee', 'eeee', 'eeee@eeee.eeee', 'eeee', 'eeee', 'eeee', 0, 'eeee', 'eeee', '2019-05-10', 'eeee', 'eeee', 'eee', 'eeee', '', 31, NULL),
(7, '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', 1, NULL),
(8, 'sdg', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', 33, NULL),
(9, 'cv', '', '', 'cv', '', '', 0, '', '', '', '', '', '', '', '', 1, NULL),
(10, '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', 1, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `my_user`
--

DROP TABLE IF EXISTS `my_user`;
CREATE TABLE IF NOT EXISTS `my_user` (
  `username` varchar(25) NOT NULL,
  `password` varchar(40) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gender` int(11) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `firstName` varchar(20) DEFAULT 'firstname',
  `lastName` varchar(20) DEFAULT 'lastname',
  `vip` int(11) NOT NULL DEFAULT '1',
  `address` varchar(40) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `postCode` varchar(20) DEFAULT NULL,
  `about` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `my_user`
--

INSERT INTO `my_user` (`username`, `password`, `id`, `gender`, `email`, `firstName`, `lastName`, `vip`, `address`, `city`, `country`, `postCode`, `about`) VALUES
('aaaa', 'aaaa', 1, 1, 'aaaa@aaaa.aaaa', 'aaa', 'aaa', 1, 'aaaaa', 'aaa', 'aaaaa', 'aaaa', '      aaaahtehenhy'),
('bbbb', 'bbbb', 28, 1, 'bbbb@bbbb.bbbb', 'bbbb', 'bbbb', 1, 'bbbb', 'bbbb', 'bbbb', 'bbbb', 'bbbb'),
('cccc', 'cccc', 29, NULL, 'cccc@cccc.cccc', 'firstname', 'lastname', 1, 'cccc', 'cccc', 'cccc', 'cccc', 'cccc '),
('dddd', 'dddd', 30, NULL, 'dddd', 'firstname', 'lastname', 1, NULL, NULL, NULL, NULL, NULL),
('eeee', 'eeee', 31, NULL, 'eeee', 'firstname', 'lastname', 1, NULL, NULL, NULL, NULL, NULL),
('ffff', 'ffff', 32, NULL, 'ffff', 'firstname', 'lastname', 1, NULL, NULL, NULL, NULL, NULL),
('Wangxh', 'Wqwedsazxc', 33, NULL, 'Wangxhwo@163.com', 'firstname', 'lastname', 1, '123', '123', '123', '123', ' 123123123');

-- --------------------------------------------------------

--
-- 表的结构 `think_data`
--

DROP TABLE IF EXISTS `think_data`;
CREATE TABLE IF NOT EXISTS `think_data` (
  `id` int(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '名称',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `think_data`
--

INSERT INTO `think_data` (`id`, `name`, `status`) VALUES
(1, 'thinkphp', 1),
(2, 'onethink', 1),
(3, 'topthink', 1);

-- --------------------------------------------------------

--
-- 表的结构 `think_user`
--

DROP TABLE IF EXISTS `think_user`;
CREATE TABLE IF NOT EXISTS `think_user` (
  `id` int(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nickname` varchar(50) NOT NULL COMMENT '昵称',
  `email` varchar(255) DEFAULT NULL COMMENT '邮箱',
  `birthday` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '生日',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '注册时间',
  `update_time` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `think_user`
--

INSERT INTO `think_user` (`id`, `nickname`, `email`, `birthday`, `status`, `create_time`, `update_time`) VALUES
(1, '流年', 'thinkphp@qq.com', 226339200, 0, 0, 0),
(2, '张三', 'zhanghsan@qq.com', 569174400, 0, 0, 0),
(3, '李四', 'lisi@qq.com', 653673600, 0, 0, 0),
(4, '张三', 'zhanghsan@qq.com', 569174400, 0, 0, 0),
(5, '李四', 'lisi@qq.com', 653673600, 0, 0, 0),
(6, '看云', 'kancloud@qq.com', 1427904000, 0, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `yunzhi_user`
--

DROP TABLE IF EXISTS `yunzhi_user`;
CREATE TABLE IF NOT EXISTS `yunzhi_user` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT '' COMMENT '姓名',
  `sex` tinyint(1) UNSIGNED NOT NULL DEFAULT '0' COMMENT '0男，1女',
  `username` varchar(16) NOT NULL COMMENT '用户名',
  `password` varchar(40) NOT NULL COMMENT '密码',
  `email` varchar(30) DEFAULT '' COMMENT '邮箱',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `yunzhi_user`
--

INSERT INTO `yunzhi_user` (`id`, `name`, `sex`, `username`, `password`, `email`, `create_time`, `update_time`) VALUES
(18, 'dddd', 0, 'dddd', '8251475c8c85f72a4c7e8ba16447a674730546d5', 'dddd@dddd', 1554083882, 1554083882),
(17, 'cccc', 1, 'cccc', '6d1da262a30889d37412fdf47ec13ad70cc2b02c', 'cccc@cccc.cccc', 1554044004, 1554044004),
(16, 'bbbb', 0, 'bbbb', '281de3bc5566fb02eae5068637391e6b89626e3a', 'bbbb@bbbb.bbbb', 1554043992, 1554043992),
(15, 'aaaa', 0, 'aaaa', '150d5c8582b3aeec70955dc9f271a640a94afcd3', 'aaaa@aaaa.aaaa', 1554043976, 1554043976),
(19, 'eeee', 0, 'eeee', '72ac1539c6eb5fee8ec5211f8986adf70e528070', 'eeee@eeee.eeee', 1554083892, 1554083892),
(20, 'ffff', 0, 'ffff', '7717b851eb61f8fd7162877b26a57ae087554f4d', 'ffff@ffff.ffff', 1554083912, 1554083912),
(21, 'gggg', 0, 'gggg', '588d61554f98895ac542ea45f7dd1049088079ca', 'gggg@gggg.gggg', 1554083921, 1554083921),
(22, 'hhhh', 0, 'hhhh', 'c73a3ab9cc68d9c091977f370335442be3dbd676', 'hhhh@hhhh.hhhh', 1554083933, 1554083933),
(23, 'gggg', 0, 'gggg', '588d61554f98895ac542ea45f7dd1049088079ca', 'gggg@ggg.ggg', 1554085235, 1554085235),
(24, '', 0, 'mmmm', '855f9240fcb5f701060e6d44c3580b71d93413e9', 'mmmm@mmmm.mmmm', 1554170274, 1554170274),
(25, '', 0, 'mmmm', '855f9240fcb5f701060e6d44c3580b71d93413e9', 'mmmm@mmmm.mmmm', 1554170335, 1554170335),
(26, '', 0, 'mmmm', '855f9240fcb5f701060e6d44c3580b71d93413e9', 'mmmm@mmmm.mmmm', 1554170349, 1554170349),
(27, '', 0, 'mmmm', '855f9240fcb5f701060e6d44c3580b71d93413e9', 'mmmm@mmmm.mmmm', 1554170366, 1554170366),
(28, '', 0, 'mmmm', '855f9240fcb5f701060e6d44c3580b71d93413e9', 'mmmm@mmmm.mmmm', 1554170380, 1554170380),
(29, '', 0, 'mmmm', '855f9240fcb5f701060e6d44c3580b71d93413e9', 'mmmm@mmmm.mmmm', 1554170398, 1554170398),
(30, '', 0, 'mmmm', '855f9240fcb5f701060e6d44c3580b71d93413e9', 'mmmm@mmmm.mmmm', 1554170415, 1554170415),
(31, '', 0, 'hhhh', 'c73a3ab9cc68d9c091977f370335442be3dbd676', 'hhhh@hhhh.hhhh', 1554170882, 1554170882),
(32, '', 0, 'jjjj', '931600bac0eda48a3b271ef788348e66fbd0fe9a', 'jjjj@jjjj.jjjj', 1554170925, 1554170925),
(33, '', 0, 'iiii', 'fe7ece9025decd9681c14780bb6e548325f0e1ee', 'iiii@iiii.iiii', 1554171231, 1554171231),
(34, '', 0, '', 'f819e4dda1ec2eaf87bba8c125bbf11d93a7bbc5', '', 1554171306, 1554171306),
(35, '', 0, 'asdf', '76923f959cfe84339b21d3dcfa80ea72752d07dc', 'asdfasf@asdf', 1554171367, 1554171367),
(36, '', 0, 'asdf', '76923f959cfe84339b21d3dcfa80ea72752d07dc', 'asfd@afd.asfd', 1554171382, 1554171382),
(37, 'asdfadsf', 0, 'asdfasdf', 'asdfsadf', 'asdf@asdfasd.asdf', 1554172379, 1554172379),
(38, 'asdfadsf', 0, 'asdfasdfffff', 'asdfsadf', 'asdf@asdfasd.asdf', 1554172520, 1554172520),
(39, 'asdf', 0, 'asdfasdfasfd', 'asdf', 'asdf@adf.sadf', 1554172830, 1554172830),
(40, 'asdf', 0, 'asdfzxvc', 'asdf', 'asdf@adf.sadf', 1554172858, 1554172858),
(41, 'sadfhghf', 0, 'rtyuiklkjhgfd', 'sadfdhgkjlf;jg\'kh', 'adsf@afhdg.dsagfhdg', 1554173159, 1554173159),
(42, 'sadfsafasfd', 0, 'sadfsadfsadfn', 'asdfzxvczvc', 'saffs@easf.asdf', 1554173229, 1554173229);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
