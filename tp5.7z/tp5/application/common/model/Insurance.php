<?php
/**
 * Created by PhpStorm.
 * User: wxhke
 * Date: 2019/4/25
 * Time: 14:46
 */
namespace app\index\model;
use think\Model;
use think\Cookie;
use think\Request;
class Insurance extends Model
{
    static public function insertLoss($postDate)
    {

    }
}