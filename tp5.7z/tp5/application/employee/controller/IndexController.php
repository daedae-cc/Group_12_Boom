<?php
namespace app\employee\controller;

use think\Controller;

class IndexController extends Controller
{
    public function index()
    {
        return $this->fetch();
    }

    public function signIn(){

    }

}
