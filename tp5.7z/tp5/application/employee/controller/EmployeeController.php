<?php
/**
 * Created by PhpStorm.
 * User: wxhke
 * Date: 2019/4/4
 * Time: 4:31
 */

namespace app\employee\controller;


use think\Controller;

class EmployeeController extends Controller
{
    public function index()
    {
        return "eei";
    }
}