<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:99:"D:\Work\wamp64\www\Group_12_Boom\tp5\public/../application/employee\view\work\temp_loss_detail.html";i:1556727204;}*/ ?>
<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <title>temp loss detail</title>
</head>
<body>
<?php echo $loss; ?>


<br/>

<?php if($loss->getData("status")== 0): ?>this is 0
<a href="<?php echo url('employee/work/addProcessLoss', ['id' => $loss->getData('id')]); ?>">add it to process</a>
<a href="<?php echo url('employee/work/processLoss',['id' => $loss->getData('id')]); ?>">Start deal it</a>
<?php elseif($loss->getData("status")== 1): ?>
<form class="cont_form_sign_up" action="<?php echo url('employee/work/finishLoss',['id' => $loss->getData('id')]); ?>" method="post">
    <input type="number" name="pay">
    <button class="btn_sign_up" type="submit">pay</button>
</form>
<?php else: endif; ?>


</body>
</html>

