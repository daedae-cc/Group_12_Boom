<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:92:"D:\Work\wamp64\www\Group_12_Boom\tp5\public/../application/employee\view\work\show_user.html";i:1554323452;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>show User</title>
</head>
<body class="container">
<div class="row">
    <div class="col-md-12">
        <table class="table table-hover table-bordered">
            <tr class="info">
                <th>id</th>
                <th>username</th>
                <th>gender</th>
                <th>email</th>
                <th>first name</th>
                <th>last name</th>
                <th>VIP</th>
            </tr>
            <?php if(is_array($users) || $users instanceof \think\Collection || $users instanceof \think\Paginator): $key = 0; $__LIST__ = $users;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$user): $mod = ($key % 2 );++$key;?>
            <tr>
                <td><?php echo $user->getData('id'); ?></td>
                <td><?php echo $user->getData('username'); ?></td>
                <td><?php echo $user->getData('gender'); ?></td>
                <td><?php echo $user->getData('email'); ?></td>
                <td><?php echo $user->getData('firstname'); ?></td>
                <td><?php echo $user->getData('lastname'); ?></td>
                <td><?php echo $user->getData('vip'); ?></td>
            </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </table>
    </div>
</div>
</body>

</html>