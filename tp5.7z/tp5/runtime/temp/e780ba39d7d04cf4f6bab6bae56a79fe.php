<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:94:"D:\Work\wamp64\www\Group_12_Boom\tp5\public/../application/employee\view\work\user_detail.html";i:1556701548;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <link rel="icon" href="/public/static/favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <title>userDetail</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width"/>


    <!-- Bootstrap core CSS     -->
    <link href="/public/static/dist/css/bootstrap.min.css" rel="stylesheet"/>

    <!--  User Profile CSS    -->
    <link href="/public/static/css/user.css" rel="stylesheet"/>

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <!--  <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300|Material+Icons' rel='stylesheet' type='text/css'/> -->
    <link href="/public/static/iconfont/material-icons.css" rel="stylesheet"/>
</head>

<body>
<div class="main-panel">

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-10">
                    <div class="card">
                        <div class="card-header" data-background-color="purple">
                            <h4 class="title">Profile</h4>
                            <p class="category">The following is your profile</p>
                        </div>
                        <div class="card-content">
                            <form>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Username</label>
                                            <input type="text" class="form-control" disabled
                                                   value="<?php echo $user->getData('username'); ?>" name="username">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Email address</label>
                                            <input type="email" class="form-control" disabled
                                                   value="<?php echo $user->getData('email'); ?>" name="email">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group label-floating">
                                            <label class="control-label">First Name</label>
                                            <input type="text" class="form-control" disabled
                                                   value="<?php echo $user->getData('firstName'); ?>" name="firstName">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Last Name</label>
                                            <input type="text" class="form-control" disabled
                                                   value="<?php echo $user->getData('lastName'); ?>" name="lastName">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Address</label>
                                            <input type="text" class="form-control" disabled
                                                   value="<?php echo $user->getData('address'); ?>" name="address">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">City</label>
                                            <input type="text" class="form-control" disabled
                                                   value="<?php echo $user->getData('city'); ?>" name="city">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Country</label>
                                            <input type="text" class="form-control" disabled
                                                   value="<?php echo $user->getData('country'); ?>" name="country">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group label-floating">
                                            <label class="control-label">Postal Code</label>
                                            <input type="text" class="form-control" disabled
                                                   value="<?php echo $user->getData('postCode'); ?>" name="postCode">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <div class="form-group label-floating">
                                                <label class="control-label">About me</label>
                                                <textarea class="form-control" rows="5" disabled name="about"> <?php echo $user->getData('about'); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <a class="btn btn-primary pull-right" href="<?php echo url('employee/work/index'); ?>"
                                   role="button">Go back</a>
                                <div class="clearfix"></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</body>

<!--   Core JS Files   -->
<script src="/public/static/dist/js/jquery-3.1.0.min.js" type="text/javascript"></script>
<script src="/public/static/dist/js/bootstrap.min.js" type="text/javascript"></script>
<script src="/public/static/dist/js/material.min.js" type="text/javascript"></script>

<!-- javascript methods -->
<script src="/public/static/js/user.js"></script>

</html>
