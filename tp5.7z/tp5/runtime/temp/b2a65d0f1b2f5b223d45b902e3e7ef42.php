<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:90:"D:\Work\wamp64\www\Group_12_Boom\tp5\public/../application/index\view\insurance\index.html";i:1556175684;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Insurance</title>
</head>
<body>
<p><a class="btn btn-default" href="<?php echo url('index/insurance/purchase'); ?>" role="button">View details &raquo;</a></p>
<p><a class="btn btn-default" href="<?php echo url('index/insurance/purchase'); ?>" role="button">View details &raquo;</a></p>
<p><a class="btn btn-default" href="<?php echo url('index/insurance/purchase'); ?>" role="button">View details &raquo;</a></p>
</body>
</html>