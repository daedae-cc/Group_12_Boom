<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:88:"D:\Work\wamp64\www\Group_12_Boom\tp5\public/../application/employee\view\work\index.html";i:1556724071;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/public/static/favicon.ico">

    <title>Customers</title>

    <!-- Bootstrap core CSS -->
    <link href="/public/static/dist4/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:700,900" rel="stylesheet">
    <link href="/public/static/css/employeeInterface.css" rel="stylesheet">
</head>


<div class="container">
    <header class="blog-header py-3">
        <div class="row flex-nowrap justify-content-between align-items-center">
            <div class="col-4 pt-1">
                <p>EmployeeId:<?php echo session('employeeId'); ?></p>
            </div>
            <div class="col-4 text-center">
                <a class="blog-header-logo text-dark" href="#">Customer</a>
            </div>
            <div class="col-4 d-flex justify-content-end align-items-center">
                <a class="btn btn-sm btn-outline-secondary" href="<?php echo url('employee/sign_in/logOut'); ?>">Log out</a>
            </div>
        </div>
    </header>

    <div class="nav-scroller py-1 mb-2">
        <nav class="nav d-flex justify-content-between">
            <a href="<?php echo url('employee/work/index'); ?>" class="btn btn-primary"><i class="glyphicon glyphicon-plus"></i>&nbsp;Customers</a>
            <a href="<?php echo url('employee/work/showNewLoss'); ?>" class="btn btn-primary"><i
                    class="glyphicon glyphicon-plus"></i>&nbsp;news</a>
            <a href="<?php echo url('employee/work/showProcessLoss'); ?>" class="btn btn-primary"><i
                    class="glyphicon glyphicon-plus"></i>&nbsp;processing</a>
            <a href="<?php echo url('employee/work/showFinishLoss'); ?>" class="btn btn-primary"><i
                    class="glyphicon glyphicon-plus"></i>&nbsp;finished</a>
        </nav>
    </div>
</div>

<!--    <hr/>-->
<!--    <a href="<?php echo url('employee/work/index'); ?>" class="btn btn-primary"><i class="glyphicon glyphicon-plus"></i>&nbsp;Customers</a>-->
<!--    <a href="<?php echo url('employee/work/showNewLoss'); ?>" class="btn btn-primary"><i class="glyphicon glyphicon-plus"></i>&nbsp;news</a>-->
<!--    <a href="<?php echo url('employee/work/showProcessLoss'); ?>" class="btn btn-primary"><i class="glyphicon glyphicon-plus"></i>&nbsp;processing</a>-->
<!--    <a href="<?php echo url('employee/work/showFinishLoss'); ?>" class="btn btn-primary"><i class="glyphicon glyphicon-plus"></i>&nbsp;finished</a>-->
<!--    <hr/>-->
<div class="row">
    <div class="col-md-12">
        <form class="form-inline" method="post" action="<?php echo url(); ?>">
            <div class="form-group">
                <label class="sr-only" for="name">name</label>
                <input name="name" type="text" class="form-control" placeholder="name...">
            </div>
            <button type="submit" class="btn btn-default"><i class="glyphicon glyphicon-search"></i>&nbsp;search
            </button>
        </form>
    </div>
</div>

<br/>

<body class="container">
<div class="row">
    <div class="col-md-12">
        <table class="table table-hover table-bordered">
            <tr class="info">
                <th>id</th>
                <th>username</th>
                <th>gender</th>
                <th>email</th>
                <th>first name</th>
                <th>last name</th>
                <th>VIP</th>
                <th></th>

            </tr>
            <?php if(is_array($users) || $users instanceof \think\Collection || $users instanceof \think\Paginator): $key = 0; $__LIST__ = $users;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$user): $mod = ($key % 2 );++$key;?>
            <tr>
                <td><?php echo $user->getData('id'); ?></td>
                <td><?php echo $user->getData('username'); ?></td>
                <td><?php echo $user->getData('gender'); ?></td>
                <td><?php echo $user->getData('email'); ?></td>
                <td><?php echo $user->getData('firstName'); ?></td>
                <td><?php echo $user->getData('lastName'); ?></td>
                <td><?php echo $user->getData('vip'); ?></td>
                <td>
                    <a href="<?php echo url('employee/work/userDetail',['id'=> $user->getData('id')]); ?>">detail</a>
                </td>
            </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </table>
        <?php echo $users->render(); ?>
    </div>
</div>
</body>
</html>