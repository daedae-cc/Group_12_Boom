<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"D:\Work\wamp64\www\Group_12_Boom\tp5\public/../application/index\view\login\index.html";i:1554040881;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>login</title>
</head>
<body>
<form action="<?php echo url('login'); ?>" method="post">
    <label for="username">username:</label><input type="text" name="username" id="username" />
    <label for="password">password:</label><input type="password" name="password" id="password" />
    <button type="submit">submit</button>
</form>
</body>
</html>
