<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"D:\Work\wamp64\www\Group_12_Boom\tp5\public/../application/index\view\index\about.html";i:1556695711;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/public/static/favicon.ico">

    <title>About Us</title>

    <!-- Bootstrap core CSS -->
    <link href="/public/static/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="/public/static/assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="/public/static/assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="/public/static/assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="/public/static/css/about.css" rel="stylesheet">
</head>
<!-- NAVBAR
================================================== -->
<body>
<div class="navbar-wrapper">
    <div class="container">
        <nav class="navbar navbar-inverse navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                            aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Hibernia-Sino</a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="<?php echo url('index/index/index'); ?>">Home</a></li>
                        <li><a href=<?php echo url('index/index/about'); ?>>About</a></li>
                        <li><a href="<?php echo url('index/index/contact'); ?>">Contact</a></li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                               aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="#">Action</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something else here</a></li>
                                <li role="separator" class="divider"></li>
                                <li class="dropdown-header">Nav header</li>
                                <li><a href="#">Separated link</a></li>
                                <li><a href="#">One more separated link</a></li>
                            </ul>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <?php if($isLogin == 'true'): ?>
                        <li><a href="<?php echo url('index/signIn/logOut'); ?>"><span
                                class="glyphicon glyphicon-log-in"></span>
                            logout</a></li>
                        <?php else: ?>
                        <li><a href="<?php echo url('index/signIn/index'); ?>"><span
                                class="glyphicon glyphicon-log-in"></span>
                            Sign Up/Sign in</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</div>


<!-- Carousel
================================================== -->
<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner" role="listbox">
        <div class="item active">
            <img class="first-slide" src="/public/static/assets/img/image2.png" alt="First slide">
        </div>

        <div class="container">
            <div class="zone zone-content">
                <article class="partner-public-content-page content-item">
                    <section class='Mhero Mhero--photo'>
                        <div class="row">
                            <div class="Mhero-inner small-12 medium-7 large-5 column">
                                <div class="Mhero-intro">
                                    <div class="Mhero-media" style='background-image: url(/public/static/assets/img/image2.png)'></div>

                                    <h1 class="Mhero-title Mhero-copy">
                                        About Hibernia Sino Travel
                                    </h1>
                                </div>
                                <div class="Mhero-content">
                                    <h3 class="Mhero-copy standfirst">
                                        Here’s an introduction to our team and what we do.
                                    </h3>
                                </div>
                            </div>
                        </div>
                    </section>
                    <div class="container-hashero">
                        <div class="row">
                            <div class="small-12 medium-3 large-4 column StickySidebar sticky-container" data-sticky-container data-sticky-on="medium">
                                <nav class="NavList sticky" data-sticky data-anchor="stickySidebar">
                                    <h3 class="NavList-title">Quick links</h3>
                                    <ul class="NavList-menu" data-smoothscroll>
                                        <li>
                                            <a href="#id1">Introduction</a>
                                        </li>
                                        <li>
                                            <a href="#id2">Task Statement</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                            <div id="stickySidebar" class="small-12 medium-9 large-8 column">
                                <div class="cmsArticle-content">
                                    <h2 id="id1">Introduction</h2>
                                    <p><h5>Group Name:</h5>G12 Boom!<br><br><h5>Team Member:</h5><li>16206527 Ziqin Wu</li><li>16206952 Zezhi Wang</li><li>16206469 Zhaorui Wang</li><li>16206777 Xihao Wang</li><li>16206534 Dongxue Xia</li><br> </p>
                                    <figure>
                                        <img class="img-responsive" src="/public/static/assets/img/image1.jpg"/>
                                    </figure>
                                </div>
                                <div class="cmsArticle-content">
                                    <h2 id="id2">Task Statement</h2>
                                    <p>Our software engineering team has been hired to meet the needs of a client, the
                                        Hibernia-Sino Travel Insurance Company. Hibernia-Sino is a travel insurance company
                                        who specializes in travel between Ireland and China. They are moving their workflow
                                        processes from dated desktop software systems to the cloud. This will allow customers to
                                        update their details, renew their policies, and register claims online. The solution must be
                                        cloud-based, and work on mobile as well as PCs. Hibernia-Sino’s main concerns are the
                                        following:</p>
                                    <p>• Security</p>
                                    <p>• Reliability</p>
                                    <p>• Ease of use for the customer and for employees of Hibernia-Sino</p>
                                    <p>• The ability for users and employees to interface with the new solution in English or Chinese.</p>
                                    <p>For the First beta solution, our team is only required to deliver a system to handle lost
                                        luggage. Customers should be able to file lost luggage claims online, and employees of
                                        Hibernia-Sino should be able to process these claims online.
                                        We can email questions to the team in Hibernia but only one email per week from each
                                        team can be processed. The email address is hibernia-sino@hotmail.com.
                                        We have 12 weeks to implement a solution. In week 13 we will provide a written report
                                        documenting the software you have implemented to Hibernia-Sino. In weeks 14 and 15
                                        we will demonstrate our prototype to Hibernia-Sino. </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
        </div>


    </div><!-- /.container -->
</div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="/public/static/assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="/public/static/dist/js/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="/public/static/assets/js/vendor/holder.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="/public/static/assets/js/ie10-viewport-bug-workaround.js"></script>
</body>
</html>
