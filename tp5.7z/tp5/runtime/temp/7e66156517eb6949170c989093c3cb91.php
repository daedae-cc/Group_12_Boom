<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:90:"D:\Work\wamp64\www\Group_12_Boom\tp5\public/../application/employee\view\work\pending.html";i:1555901706;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="/public/static/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<hr/>
<a href="<?php echo url('employee/work/pending'); ?>" class="btn btn-primary"><i class="glyphicon glyphicon-plus"></i>&nbsp;pending</a>
<a href="<?php echo url('employee/work/processing'); ?>" class="btn btn-primary"><i class="glyphicon glyphicon-plus"></i>&nbsp;processing</a>
<a href="<?php echo url('employee/work/done'); ?>" class="btn btn-primary"><i class="glyphicon glyphicon-plus"></i>&nbsp;done</a>
<hr/>
<div class="row">
    <div class="col-md-8">
        <form class="form-inline" method="post" action="<?php echo url(); ?>">
            <div class="form-group">
                <label class="sr-only" for="name">name</label>
                <input name="name" type="text" class="form-control" placeholder="name...">
            </div>
            <button type="submit" class="btn btn-default"><i class="glyphicon glyphicon-search"></i>&nbsp;search
            </button>
        </form>
    </div>
</div>
<hr/>
<table class="table table-hover table-bordered">
    <tr class="info">
        <th>id</th>
        <th>passport identity</th>
        <th>email</th>
        <th>firstname</th>
        <th>lastname</th>
        <th>status</th>
        <th>pay</th>
        <th></th>
        <th></th>
        <th></th>
    </tr>
    <?php if(is_array($losses) || $losses instanceof \think\Collection || $losses instanceof \think\Paginator): $key = 0; $__LIST__ = $losses;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$loss): $mod = ($key % 2 );++$key;?>
    <tr>
        <td><?php echo $key; ?></td>
        <td><?php echo $loss->getData('id'); ?></td>
        <td><?php echo $loss->getData('pid'); ?></td>
        <td><?php echo $loss->getData('firstName'); ?></td>
        <td><?php echo $loss->getData('temporaryAddress'); ?></td>
        <td><?php echo $loss->getData('status'); ?></td>
        <td><?php echo $loss->getData('pay'); ?></td>>
        <td>
            <a href="<?php echo url('employee/work/detail',['id'=>$loss->getData('id'),'from'=>0]); ?>">detail</a>
        </td>
    </tr>
    <?php endforeach; endif; else: echo "" ;endif; ?>
</table>
<?php echo $losses->render(); ?>
</body>
</html>