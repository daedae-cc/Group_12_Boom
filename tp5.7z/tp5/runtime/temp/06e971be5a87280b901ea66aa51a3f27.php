<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:85:"D:\Work\wamp64\www\Group_12_Boom\tp5\public/../application/index\view\loss\index.html";i:1556732854;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/public/static/favicon.ico">

    <title>Homepage</title>

    <!-- Bootstrap core CSS -->
    <link href="/public/static/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="/public/static/assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]>
    <script src="/public/static/assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="/public/static/assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="/public/static/css/carousel.css" rel="stylesheet">
</head>
<!-- NAVBAR
================================================== -->

<div class="navbar-wrapper">
    <div class="container">
        <nav class="navbar navbar-inverse navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                            aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Hibernia-Sino</a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="<?php echo url('index/index/index'); ?>">Home</a></li>
                        <li><a href=<?php echo url('index/index/about'); ?>>About</a></li>
                        <li><a href="<?php echo url('index/index/contact'); ?>">Contact</a></li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                               aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="#">Action</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something else here</a></li>
                                <li role="separator" class="divider"></li>
                                <li class="dropdown-header">Nav header</li>
                                <li><a href="#">Separated link</a></li>
                                <li><a href="#">One more separated link</a></li>
                            </ul>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <?php if($isLogin == 'true'): ?>
                        <li><a href="<?php echo url('index/signIn/logOut'); ?>"><span
                                class="glyphicon glyphicon-log-in"></span>
                            logout</a></li>
                        <?php else: ?>
                        <li><a href="<?php echo url('index/signIn/index'); ?>"><span
                                class="glyphicon glyphicon-log-in"></span>
                            Sign Up/Sign in</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</div>


<br/>
<br/>
<br/>
<br/>
<br/>
<br/>

<body class="container marketing">
<div>
    <a  href="<?php echo url('index/loss/newLoss'); ?>"><button type="button" class="btn btn-primary">ADD A NEW SUBMIT</button></a>
    <br/>
</div>
<br/>
<div class="col-md-12">
    <table class="table table-hover table-bordered">
        <tr class="info">
            <th>id</th>
            <th>passport identity</th>
            <th>email</th>
            <th>firstname</th>
            <th>lastname</th>
            <th>status</th>
            <th>pay</th>
            <th></th>

        </tr>
        <?php if(is_array($losses) || $losses instanceof \think\Collection || $losses instanceof \think\Paginator): $key = 0; $__LIST__ = $losses;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$loss): $mod = ($key % 2 );++$key;?>
        <tr>
            <td><?php echo $key; ?></td>
            <td><?php echo $loss->getData('id'); ?></td>
            <td><?php echo $loss->getData('pid'); ?></td>
            <td><?php echo $loss->getData('firstName'); ?></td>
            <td><?php echo $loss->getData('temporaryAddress'); ?></td>
            <td><?php echo $loss->status; ?></td>
            <td><?php echo $loss->getData('pay'); ?></td>
            <td>
                <a href="<?php echo url('index/loss/lossDetail',['id'=>$loss->getData('id')]); ?>">detail</a>
            </td>
        </tr>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </table>
    <?php echo $losses->render(); ?>
</div>
</div>
</body>


<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="/public/static/assets/js/vendor/jquery.min.js"><\/script>')</script>
<script src="/public/static/dist/js/bootstrap.min.js"></script>
<!-- Just to make our placeholder images work. Don't actually copy the next line! -->
<script src="/public/static/assets/js/vendor/holder.min.js"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="/public/static/assets/js/ie10-viewport-bug-workaround.js"></script>
</body>
</html>
