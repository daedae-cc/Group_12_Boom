<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:91:"D:\Work\wamp64\www\Group_12_Boom\tp5\public/../application/index\view\loss\loss_detail.html";i:1556727016;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <link rel="icon" href="/public/static/favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <title>loss detail</title>


    <!-- Bootstrap core CSS -->
    <link href="/public/static/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="/public/static/assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Bootstrap core CSS     -->
    <link href="/public/static/dist/css/bootstrap.min.css" rel="stylesheet"/>

    <!--  User Profile CSS    -->
    <link href="/public/static/css/form.css" rel="stylesheet"/>

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <!--  <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300|Material+Icons' rel='stylesheet' type='text/css'/> -->
    <link href="/public/static/iconfont/material-icons.css" rel="stylesheet"/>
</head>


<body>
<div class="navbar-wrapper">
    <div class="container">
        <nav class="navbar navbar-inverse navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                            aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Hibernia-Sino</a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="<?php echo url('index/index/index'); ?>">Home</a></li>
                        <li><a href=<?php echo url('index/index/about'); ?>>About</a></li>
                        <li><a href="<?php echo url('index/index/contact'); ?>">Contact</a></li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                               aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="#">Action</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something else here</a></li>
                                <li role="separator" class="divider"></li>
                                <li class="dropdown-header">Nav header</li>
                                <li><a href="#">Separated link</a></li>
                                <li><a href="#">One more separated link</a></li>
                            </ul>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <?php if($isLogin == 'true'): ?>
                        <li><a href="<?php echo url('index/signIn/logOut'); ?>"><span
                                class="glyphicon glyphicon-log-in"></span>
                            logout</a></li>
                        <?php else: ?>
                        <li><a href="<?php echo url('index/signIn/index'); ?>"><span
                                class="glyphicon glyphicon-log-in"></span>
                            Sign Up/Sign in</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</div>

<div class="wrapper">
    <div class="main-panel">

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-10">
                        <div class="card">
                            <div class="card-header" data-background-color="purple">
                                <h4 class="title">Luggage Loss Form</h4>
                                <p class="category">We would like to offer our apologies for not being able to deliver
                                    your luggage on your arrival, Would you please complete this form and forward to the
                                    address given above if you do not receive luggage within 72 hours after your
                                    report.Thanks.</p>
                            </div>
                            <div class="card-content">
                                <form action="<?php echo url('index/Loss/insertLoss'); ?>" method="post">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Passport or other identification
                                                    No.:</label>
                                                <input disabled type="text" class="form-control" name="pid" value="<?php echo $loss->getData('pid'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Name:</label>
                                                <input disabled type="text" class="form-control" name="firstName" value="<?php echo $loss->getData('firstName'); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Permanent residence address&Tel:</label>
                                                <input disabled type="text" class="form-control" name="permanentAddress" value="<?php echo $loss->getData('permanentAddress'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group label-floating">
                                                <label class="control-label">E-mail:</label>
                                                <input disabled type="email" class="form-control" name="email" value="<?php echo $loss->getData('email'); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Temporary residence address&Tel:</label>
                                                <input disabled type="text" class="form-control" name="temporaryAddress" value="<?php echo $loss->getData('temporaryAddress'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Post Code:</label>
                                                <input disabled type="text" class="form-control" name="postCode" value="<?php echo $loss->getData('postCode'); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-2">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Airline:</label>
                                                <input disabled type="text" class="form-control" name="airline" value="<?php echo $loss->getData('airline'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Flight No.:</label>
                                                <input disabled type="text" class="form-control" name="fNo" value="<?php echo $loss->getData('fNo'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Date:</label>
                                                <input disabled type="date" class="form-control" name="date" value="<?php echo $loss->getData('date'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group label-floating">
                                                <label class="control-label">From:</label>
                                                <input disabled type="text" class="form-control" name="fromP" value="<?php echo $loss->getData('fromP'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group label-floating">
                                                <label class="control-label">To:</label>
                                                <input disabled type="text" class="form-control" name="toP" value="<?php echo $loss->getData('toP'); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Type and Colour:</label>
                                                <input disabled type="text" class="form-control" name="typeColor" value="<?php echo $loss->getData('typeColor'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Brand name:</label>
                                                <input disabled  type="text" class="form-control" name="brandName" value="<?php echo $loss->getData('brandName'); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Please write down the name or any other
                                                        special label on your luggage.</label>
                                                    <textarea disabled class="form-control" rows="5" name="more" value="<?php echo $loss->getData('more'); ?>"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
<!--                                    <button type="submit" class="btn btn-primary pull-right" >Submit</button>-->
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

</body>

<!--   Core JS Files   -->
<script src="/public/static/dist/js/jquery-3.1.0.min.js" type="text/javascript"></script>
<script src="/public/static/dist/js/bootstrap.min.js" type="text/javascript"></script>
<script src="/public/static/dist/js/material.min.js" type="text/javascript"></script>

<!-- javascript methods -->
<script src="/public/static/js/form.js"></script>

</html>
