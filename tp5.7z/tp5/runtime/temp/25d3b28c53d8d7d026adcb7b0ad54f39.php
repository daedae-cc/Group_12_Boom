<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"D:\Work\wamp64\www\Group_12_Boom\tp5\public/../application/test\view\index\show.html";i:1556692542;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>show</title>
</head>
<body>
<p>come from <?php echo $page; ?></p>
<a href="<?php echo url('test/index/index'); ?>">go home</a>
</body>
</html>