<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:85:"D:\Work\wamp64\www\Group_12_Boom\tp5\public/../application/test\view\index\index.html";i:1556692698;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>index/index</title>
</head>
<body>
<!--{} used to use the code -->
    <p>this is the data:<?php echo $v; ?></p>
    <br/>
    <a href="<?php echo url('test/index/tRedirection'); ?>">tRedirection</a>
</body>
</html>