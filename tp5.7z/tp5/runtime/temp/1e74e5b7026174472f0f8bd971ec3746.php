<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:94:"D:\Work\wamp64\www\Group_12_Boom\tp5\public/../application/employee\view\work\loss_detail.html";i:1556733275;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/public/static/favicon.ico">

    <title>Loss Detail</title>

    <!-- Bootstrap core CSS -->
    <link href="/public/static/dist4/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:700,900" rel="stylesheet">
    <link href="/public/static/css/employeeInterface.css" rel="stylesheet">
    <link href="/public/static/css/form.css" rel="stylesheet"/>
</head>


<div class="container">
    <header class="blog-header py-3">
        <div class="row flex-nowrap justify-content-between align-items-center">
            <div class="col-4 pt-1">
                <p>EmployeeId:<?php echo session('employeeId'); ?></p>
            </div>
            <div class="col-4 text-center">
                <a class="blog-header-logo text-dark" href="#">Loss Detail</a>
            </div>
            <div class="col-4 d-flex justify-content-end align-items-center">
                <a class="btn btn-sm btn-outline-secondary" href="<?php echo url('employee/sign_in/logOut'); ?>">Log out</a>
            </div>
        </div>
    </header>
</div>

<div class="wrapper">
    <div class="main-panel">

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-10">
                        <div class="card">
                            <div class="card-header" data-background-color="purple">
                                <h4 class="title">Luggage Loss Form</h4>
                                <p class="category">We would like to offer our apologies for not being able to deliver
                                    your luggage on your arrival, Would you please complete this form and forward to the
                                    address given above if you do not receive luggage within 72 hours after your
                                    report.Thanks.</p>
                            </div>
                            <div class="card-content">
                                <form action="<?php echo url('index/Loss/insertLoss'); ?>" method="post">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Passport or other identification
                                                    No.:</label>
                                                <input disabled type="text" class="form-control" name="pid"
                                                       value="<?php echo $loss->getData('pid'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Name:</label>
                                                <input disabled type="text" class="form-control" name="firstName"
                                                       value="<?php echo $loss->getData('firstName'); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Permanent residence address&Tel:</label>
                                                <input disabled type="text" class="form-control" name="permanentAddress"
                                                       value="<?php echo $loss->getData('permanentAddress'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group label-floating">
                                                <label class="control-label">E-mail:</label>
                                                <input disabled type="email" class="form-control" name="email"
                                                       value="<?php echo $loss->getData('email'); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Temporary residence address&Tel:</label>
                                                <input disabled type="text" class="form-control" name="temporaryAddress"
                                                       value="<?php echo $loss->getData('temporaryAddress'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Post Code:</label>
                                                <input disabled type="text" class="form-control" name="postCode"
                                                       value="<?php echo $loss->getData('postCode'); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-2">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Airline:</label>
                                                <input disabled type="text" class="form-control" name="airline"
                                                       value="<?php echo $loss->getData('airline'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Flight No.:</label>
                                                <input disabled type="text" class="form-control" name="fNo"
                                                       value="<?php echo $loss->getData('fNo'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Date:</label>
                                                <input disabled type="date" class="form-control" name="date"
                                                       value="<?php echo $loss->getData('date'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group label-floating">
                                                <label class="control-label">From:</label>
                                                <input disabled type="text" class="form-control" name="fromP"
                                                       value="<?php echo $loss->getData('fromP'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group label-floating">
                                                <label class="control-label">To:</label>
                                                <input disabled type="text" class="form-control" name="toP"
                                                       value="<?php echo $loss->getData('toP'); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Type and Colour:</label>
                                                <input disabled type="text" class="form-control" name="typeColor"
                                                       value="<?php echo $loss->getData('typeColor'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group label-floating">
                                                <label class="control-label">Brand name:</label>
                                                <input disabled type="text" class="form-control" name="brandName"
                                                       value="<?php echo $loss->getData('brandName'); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Please write down the name or any other
                                                        special label on your luggage.</label>
                                                    <textarea disabled class="form-control" rows="5" name="more"
                                                              value="<?php echo $loss->getData('more'); ?>"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--                                    <button type="submit" class="btn btn-primary pull-right" >Submit</button>-->
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div>
                <?php if($loss->getData("status")== 0): ?>
                <a href="<?php echo url('employee/work/addProcessLoss', ['id' => $loss->getData('id')]); ?>">
                    <button type="button" class="btn btn-primary">add it to
                        process
                    </button>
                </a>
                <a href="<?php echo url('employee/work/processLoss',['id' => $loss->getData('id')]); ?>">
                    <button type="button" class="btn btn-primary">Start deal it
                    </button>
                </a>
                <?php elseif($loss->getData("status")== 1): ?>
                <form class="cont_form_sign_up"
                      action="<?php echo url('employee/work/finishLoss',['id' => $loss->getData('id')]); ?>"
                      method="post">
                    <input type="number" name="pay">
                    <input class="btn btn-primary" type="submit" value="Pay"></input>
                </form>
                <?php else: endif; ?>
            </div>
        </div>

    </div>
</div>


<!--   Core JS Files   -->
<script src="/public/static/dist/js/jquery-3.1.0.min.js" type="text/javascript"></script>
<script src="/public/static/dist/js/bootstrap.min.js" type="text/javascript"></script>
<script src="/public/static/dist/js/material.min.js" type="text/javascript"></script>

<!-- javascript methods -->
<script src="/public/static/js/form.js"></script>

</html>
