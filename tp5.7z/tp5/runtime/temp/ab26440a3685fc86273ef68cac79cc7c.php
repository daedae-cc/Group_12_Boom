<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:89:"D:\Work\wamp64\www\Group_12_Boom\tp5\public/../application/employee\view\work\detail.html";i:1555901706;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <title>Employee</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width"/>

    <!-- Bootstrap core CSS     -->
    <link href="/public/static/dist/css/bootstrap.min.css" rel="stylesheet"/>

    <!--  Material Dashboard CSS    -->
    <link href="/public/static/dist/css/material-dashboard.css" rel="stylesheet"/>

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet"/>
    <!--  <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300|Material+Icons' rel='stylesheet' type='text/css'/> -->

    <link href="/public/static/iconfont/material-icons.css" rel="stylesheet"/>
</head>

<body>

<div class="wrapper">
    <div class="sidebar" data-color="purple">
        <div class="logo">
				<span class="simple-text">
					Hibernia-Sino<br>Company
				</span>
        </div>

        <div class="sidebar-wrapper">
            <ul class="nav">
                <li>
                    <a href="dashboard.html">
                        <i class="material-icons">dashboard</i>
                        <p>Dashboard</p>
                    </a>
                </li>

                <li class="active">
                    <a href="table.html">
                        <i class="material-icons">content_paste</i>
                        <p>Table List</p>
                    </a>
                </li>

                <li>
                    <a href="notifications.html">
                        <i class="material-icons text-gray">notifications</i>
                        <p>Notifications</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-transparent navbar-absolute">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Table List</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="#pablo" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="material-icons">dashboard</i>
                                <p class="hidden-lg hidden-md">Dashboard</p>
                            </a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="material-icons">notifications</i>
                                <span class="notification">2</span>
                                <p class="hidden-lg hidden-md">Notifications</p>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="#">Please deal with the lost luggage in time </a></li>
                                <li><a href="#">you will decide the final amount to be paid</a></li>

                            </ul>
                        </li>
                        <li>
                            <a href="#pablo" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="material-icons">person</i>
                                <p class="hidden-lg hidden-md">Profile</p>
                            </a>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>


        <style>
            .bd-placeholder-img {
                font-size: 1.125rem;
                text-anchor: middle;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
            }

            @media (min-width: 768px) {
                .bd-placeholder-img-lg {
                    font-size: 3.5rem;
                }
            }
        </style>
        <!-- Custom styles for this template -->
        <link href="./Checkout example · Bootstrap_files/form-validation.css" rel="stylesheet">
        </head>
        <body class="bg-light">
        <div class="container">
            <div class="py-5 text-center">
                <h2>Insurance Policy</h2>
            </div>

            <div class="row">
                <div class="col-md-4 order-md-2 mb-4">
                    <h4 class="d-flex justify-content-between align-items-center mb-3">
                        <span class="text-muted">Result</span>
                        <span class="badge badge-secondary badge-pill">5</span>
                    </h4>
                    <ul class="list-group mb-3">
                        <li class="list-group-item d-flex justify-content-between lh-condensed">
                            <div>
                                <h6 class="my-0">Policy number</h6>
                                <input type="text" class="form-control" id="policy_num" placeholder="" value=""
                                       required="">
                                <div class="invalid-feedback">
                                    Valid last name is required.
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item d-flex justify-content-between lh-condensed">
                            <div>
                                <h6 class="my-0">Compensation ratio</h6>
                                <input type="text" class="form-control" id="Compensation ratio" placeholder="" value=""
                                       required="">
                                <div class="invalid-feedback">
                                    Valid last name is required.
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item d-flex justify-content-between lh-condensed">
                            <div>
                                <h6 class="my-0">quota</h6>
                                <input type="text" class="form-control" id="quota" placeholder="" value="" required="">
                                <div class="invalid-feedback">
                                    Valid last name is required.
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item d-flex justify-content-between bg-light">
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <strong>Insured number</strong>
                            <input type="text" class="form-control" id="insured_num" placeholder="" value=""
                                   required="" name="pay">
                            <div class="invalid-feedback">
                                Valid last name is required.
                            </div>
                        </li>
                    </ul>

                    <form class="card p-2">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Policy State">
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-secondary">Saved</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-8 order-md-1">
                    <h4 class="mb-3">Details</h4>
                    <?php switch($from): case "0": ?>
                        <form class="needs-validation" novalidate="" method="post" action="<?php echo url('employee/work/pay',['id'=>$loss->getData('id')]); ?>"><?php break; case "1": ?>
                        <form class="needs-validation" novalidate="" method="post" action="<?php echo url('employee/work/processing'); ?>}"><?php break; default: ?>
                        <form class="needs-validation" novalidate="" method="post" action="<?php echo url('employee/work/done'); ?>}">
                    <?php endswitch; ?>


                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="Passport or other identification">Passport or other identification
                                    No.</label>
                                <input type="text" class="form-control" id="Passport or other identification"
                                       placeholder="" value="" required="">
                                <div class="invalid-feedback">
                                    Valid first name is required.
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="firstName">name</label>
                                <input type="text" class="form-control" id="firstName" placeholder="" value=""
                                       required="">
                                <div class="invalid-feedback">
                                    Valid last name is required.
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="phonenumber">Phone Number</label>
                                <input type="text" class="form-control" id="Number of bags check-in" placeholder=""
                                       value="" required="">
                                <div class="invalid-feedback">
                                    Valid first name is required.
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="number of bags missing">Number of bags missing</label>
                                <input type="text" class="form-control" id="Total Weight" placeholder="" value=""
                                       required="">
                                <div class="invalid-feedback">
                                    Valid last name is required.
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="approximate weight">Approximate Weight</label>
                                <input type="text" class="form-control" id="Number of bags missing" placeholder=""
                                       value="" required="">
                                <div class="invalid-feedback">
                                    Valid first name is required.
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="approximate value">Approxiate Value</label>
                                <input type="text" class="form-control" id="Approximate Weight" placeholder="" value=""
                                       required="">
                                <div class="invalid-feedback">
                                    Valid last name is required.
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="Airline">Airline</label>
                                <input type="text" class="form-control" id="Airline" placeholder="" value=""
                                       required="">
                                <div class="invalid-feedback">
                                    Valid first name is required.
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="Flight No.">Flight No.</label>
                                <input type="text" class="form-control" id="Flight No." placeholder="" value=""
                                       required="">
                                <div class="invalid-feedback">
                                    Valid last name is required.
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="start_date">Start_date</label>
                                <input type="datetime-local" class="form-control" id="start_date">
                                <div class="invalid-feedback">
                                    Valid last name is required.
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="end_date">End_date</label>
                                <input type="datetime-local" class="form-control" id="end_date">
                                <div class="invalid-feedback">
                                    Valid last name is required.
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="email">Email <span class="text-muted"></span></label>
                            <input type="email" class="form-control" id="email">
                            <div class="invalid-feedback">
                                Please enter a valid email address for shipping updates.
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="address">Permanent residence address</label>
                            <input type="text" class="form-control" id="address" required="">
                            <div class="invalid-feedback">
                                Please enter your shipping address.
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="address2">Temporary residence address<span class="text-muted"></span></label>
                            <input type="text" class="form-control" id="address2">
                        </div>


                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="Type and Colour">Type and Colour</label>
                                <input type="text" class="form-control" id="Type and Colour" placeholder="" value=""
                                       required="">
                                <div class="invalid-feedback">
                                    Valid first name is required.
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="Brand name">Brand name</label>
                                <input type="text" class="form-control" id="Brand name" placeholder="" value=""
                                       required="">
                                <div class="invalid-feedback">
                                    Valid last name is required.
                                </div>
                            </div>
                        </div>


                        <hr class="mb-4">
                        <button class="btn btn-primary btn-lg btn-block" type="submit">Finish dealing</button>
                    </form>
                </div>
            </div>


        </div>
        <script src="./Checkout example · Bootstrap_files/jquery-3.3.1.slim.min.js.下载"
                integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
                crossorigin="anonymous"></script>
        <script>window.jQuery || document.write('<script src="/docs/4.3/assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
        <script src="./Checkout example · Bootstrap_files/bootstrap.bundle.min.js.下载"
                integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o"
                crossorigin="anonymous"></script>
        <script src="./Checkout example · Bootstrap_files/form-validation.js.下载"></script>


    </div>
</div>

</body>
<!--   Core JS Files   -->
<script src="/public/static/dist/js/jquery-3.1.0.min.js" type="text/javascript"></script>
<script src="/public/static/dist/js/bootstrap.min.js" type="text/javascript"></script>
<script src="/public/static/dist/js/material.min.js" type="text/javascript"></script>

<!-- Material Dashboard javascript methods -->
<script src="/public/static/dist/js/material-dashboard.js"></script>


<script type="text/javascript">
    $(document).ready(function () {

        // Javascript method's body can be found in assets/js/demos.js
        demo.initDashboardPageCharts();

    });
</script>

</html>
